// Stripe integration removed - payment system to be implemented later
export const stripePromise = null;
